﻿# NX 1872
# Journal created by Admin on Thu May 16 15:08:06 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   功能表：插入(S)->基準/點(D)->基準平面(D)...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    datumPlaneBuilder1 = workPart.Features.CreateDatumPlaneBuilder(NXOpen.Features.Feature.Null)
    
    plane1 = datumPlaneBuilder1.GetPlane()
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    theSession.SetUndoMarkName(markId1, "基準平面 對話方塊")
    
    plane1.SetMethod(NXOpen.PlaneTypes.MethodType.FixedX)
    
    geom1 = []
    plane1.SetGeometry(geom1)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    plane1.Origin = origin1
    
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 0.0
    matrix1.Xy = 1.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 0.0
    matrix1.Yz = 1.0
    matrix1.Zx = 1.0
    matrix1.Zy = 0.0
    matrix1.Zz = 0.0
    plane1.Matrix = matrix1
    
    plane1.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane1.Evaluate()
    
    plane1.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane1.SetMethod(NXOpen.PlaneTypes.MethodType.FixedX)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    workPart.Points.DeletePoint(point1)
    
    datumPlaneBuilder1.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    theSession.UndoToMark(markId1, None)
    
    theSession.DeleteUndoMark(markId1, None)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖(H)...
    # ----------------------------------------------
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane2
    
    unit2 = workPart.UnitCollection.FindObject("MilliMeter")
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId2, "建立草圖 對話方塊")
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId3, None)
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject1 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject1
    feature1 = sketch1.Feature
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId5)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId4, None)
    
    theSession.SetUndoMarkName(markId2, "建立草圖")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane2.DestroyPlane()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->矩形(R)...
    # ----------------------------------------------
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    expression5 = workPart.Expressions.CreateSystemExpression("120")
    
    expression6 = workPart.Expressions.CreateSystemExpression("120")
    
    expression7 = workPart.Expressions.CreateSystemExpression("90")
    
    workPart.Expressions.Edit(expression5, "120")
    
    workPart.Expressions.Edit(expression6, "120")
    
    workPart.Expressions.Edit(expression7, "90")
    
    theSession.SetUndoMarkVisibility(markId7, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using From Center method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(59.999999999999929, -60.000000000000142, 0.0)
    endPoint1 = NXOpen.Point3d(60.000000000000071, 59.999999999999858, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(60.000000000000071, 59.999999999999858, 0.0)
    endPoint2 = NXOpen.Point3d(-59.999999999999929, 60.000000000000142, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(-59.999999999999929, 60.000000000000142, 0.0)
    endPoint3 = NXOpen.Point3d(-60.000000000000071, -59.999999999999858, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(-60.000000000000071, -59.999999999999858, 0.0)
    endPoint4 = NXOpen.Point3d(59.999999999999929, -60.000000000000142, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys1 = workPart.Features.FindObject("SKETCH(1:1B)")
    point3 = datumCsys1.FindObject("POINT 1")
    conGeom1_5.Geometry = point3
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line1
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = point3
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line2
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_6, conGeom2_6)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(70.034229620620707, -1.5399146209515481e-13, 0.0)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, expression5, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(9.4820103462279591e-14, 70.034229620620707, 0.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, expression6, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis1 = workPart.Datums.FindObject("SKETCH(1:1B) X axis")
    dimObject1_3.Geometry = datumAxis1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 28.574999999999999
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line1
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 60.000000000000071
    dimObject2_3.HelpPoint.Y = 59.999999999999858
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(57.0, -1.3855583347321954e-13, 0.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_3, dimObject2_3, dimOrigin3, expression7, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   功能表：插入(S)->設計特徵(E)->拉伸(X)...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit3 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit3)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("-10")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId8, "拉伸 對話方塊")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line2
    curves1[1] = line3
    curves1[2] = line1
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(-19.999999999999972, -19.99999999999995, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves1, seedPoint1, 0.01)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId9, None)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId11, None)
    
    direction1 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction1
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId10, None)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.9651907522644062
    rotMatrix1.Xy = 0.25957708404177743
    rotMatrix1.Xz = -0.032039806235963551
    rotMatrix1.Yx = 0.027973998321352958
    rotMatrix1.Yy = 0.019343102586086069
    rotMatrix1.Yz = 0.99942148255891572
    rotMatrix1.Zx = 0.26004666343021393
    rotMatrix1.Zy = -0.96552865406610955
    rotMatrix1.Zz = 0.011408374822945657
    translation1 = NXOpen.Point3d(-1.3892812042655702, 10.506533656283537, -1.4634866841527545)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.89692984317447444)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId12, None)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.SetUndoMarkName(markId8, "拉伸")
    
    expression10 = extrudeBuilder1.Limits.StartExtend.Value
    expression11 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    workPart.Expressions.Delete(expression9)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.91932497254913725
    rotMatrix2.Xy = 0.32024831504744228
    rotMatrix2.Xz = 0.22865391218346248
    rotMatrix2.Yx = -0.38596642106349749
    rotMatrix2.Yy = 0.62071472154911023
    rotMatrix2.Yz = 0.6824537759172008
    rotMatrix2.Zx = 0.076625822403175559
    rotMatrix2.Zy = -0.71564953095875472
    rotMatrix2.Zz = 0.69424364035945785
    translation2 = NXOpen.Point3d(-0.085812612168440494, 8.9216951230749615, 1.9506896435298069)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.89692984317447444)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖(H)...
    # ----------------------------------------------
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane3
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId15, "建立草圖 對話方塊")
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction2 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XY plane")
    datumCsys2 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point4 = datumCsys2.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction2, point4, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem1
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane4.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane4.SetGeometry(geom2)
    
    plane4.SetFlip(False)
    
    plane4.SetExpression(None)
    
    plane4.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane4.Evaluate()
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    plane5.SynchronizeToPlane(plane4)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom3 = [NXOpen.NXObject.Null] * 1 
    geom3[0] = datumPlane1
    plane5.SetGeometry(geom3)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.98804069731358857
    rotMatrix3.Xy = 0.15144122264116633
    rotMatrix3.Xz = 0.029002353991161488
    rotMatrix3.Yx = -0.14740790504150114
    rotMatrix3.Yy = 0.87251899292063795
    rotMatrix3.Yz = 0.46581274834855196
    rotMatrix3.Zx = 0.045238147435050634
    rotMatrix3.Zy = -0.46451712893897334
    rotMatrix3.Zz = 0.88440790755111454
    translation3 = NXOpen.Point3d(-1.0840704031299455, 7.8384899852317158, 2.9015109794880898)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.89692984317447444)
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId16, None)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject2
    feature3 = sketch2.Feature
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId18)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId17, None)
    
    theSession.SetUndoMarkName(markId15, "建立草圖")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression12)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane5.DestroyPlane()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->矩形(R)...
    # ----------------------------------------------
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId20, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(-49.0, 51.0, 0.0)
    endPoint5 = NXOpen.Point3d(-49.000000000000206, -53.0, 0.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(-49.000000000000206, -53.0, 0.0)
    endPoint6 = NXOpen.Point3d(51.327871795480682, -53.0, 0.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(51.327871795480682, -53.0, 0.0)
    endPoint7 = NXOpen.Point3d(51.327871795480689, 51.0, 0.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(51.327871795480689, 51.0, 0.0)
    endPoint8 = NXOpen.Point3d(-49.0, 51.0, 0.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line5
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_5.Geometry = line6
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line6
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line7
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line7
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line8
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line8
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line5
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom4.Geometry = line6
    geom4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom4)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line5
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line6
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line6
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line7
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line7
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line8
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line8
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line5
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line5
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line5
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(-59.034229620620806, -0.99999999999998013, 0.0)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression16 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line6
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line6
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(1.1639358977402381, -63.034229620620707, 0.0)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression17 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line5
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = -49.000000000000206
    dimObject1_6.HelpPoint.Y = -53.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis3 = workPart.Datums.FindObject("SKETCH(3:1B) X axis")
    dimObject2_6.Geometry = datumAxis3
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 28.574999999999999
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(-41.904728191276284, -7.0952718087238296, 0.0)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_6, dimObject2_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension6 = sketchDimensionalConstraint6.AssociatedDimension
    
    expression18 = sketchDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖約束(K)->尺寸(D)->快速(P)...
    # ----------------------------------------------
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines5 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines8)
    
    theSession.SetUndoMarkName(markId21, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    point5 = NXOpen.Point3d(19.174204981070346, 51.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(line8, workPart.ModelingViews.WorkView, point5)
    
    point1_1 = NXOpen.Point3d(51.327871795480689, 51.0, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, workPart.ModelingViews.WorkView, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(-49.0, 51.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line8, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    point1_3 = NXOpen.Point3d(7.1054273576010019e-14, 60.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line2, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(19.174204981070346, 51.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line8, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    point1_5 = NXOpen.Point3d(7.1054273576010019e-14, 60.0, 0.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line2, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(19.174204981070346, 51.0, 0.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line8, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(7.1054273576010019e-14, 60.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line2, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point6 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point6
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point7 = NXOpen.Point3d(-85.546452992467749, 56.637651636392455, 0.0)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point7)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = True
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject3 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId22, None)
    
    theSession.SetUndoMarkName(markId21, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId21, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId23, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression19 = workPart.Expressions.FindObject("p11")
    expression19.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId23, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId24, None)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId23, "Edit Driving Value")
    
    point8 = NXOpen.Point3d(-48.999999999999993, 2.3599021515164154, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(line5, workPart.ModelingViews.WorkView, point8)
    
    point1_8 = NXOpen.Point3d(-48.999999999999993, -45.500000000000007, 0.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line5, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(-49.0, 58.499999999999993, 0.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    point1_10 = NXOpen.Point3d(-60.0, 1.4210854715202004e-13, 0.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(-48.999999999999993, 2.3599021515164154, 0.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(-60.0, 1.4210854715202004e-13, 0.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(-48.999999999999993, 2.3599021515164154, 0.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(-60.0, 1.4210854715202004e-13, 0.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point9 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point9
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point10 = NXOpen.Point3d(-56.932639405331976, -82.596575303072271, 0.0)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point10)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject4 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.SetUndoMarkName(markId25, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId25, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId27, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression20 = workPart.Expressions.FindObject("p12")
    expression20.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId27, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId28, None)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId27, "Edit Driving Value")
    
    point11 = NXOpen.Point3d(-22.124082670465782, -45.500000000000021, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(line6, workPart.ModelingViews.WorkView, point11)
    
    point1_15 = NXOpen.Point3d(-58.499999999999972, -45.500000000000021, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(41.827871795480917, -45.500000000000021, 0.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    point1_17 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(-22.124082670465782, -45.500000000000021, 0.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(-22.124082670465782, -45.500000000000021, 0.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    point1_21 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point12 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point12
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point13 = NXOpen.Point3d(86.431416299286383, -54.867725022755195, 0.0)
    sketchRapidDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point13)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.TextCentered = False
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject5 = sketchRapidDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId29, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId29, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId31, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    expression21 = workPart.Expressions.FindObject("p13")
    expression21.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId31, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId32, None)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId31, "Edit Driving Value")
    
    point14 = NXOpen.Point3d(41.827871795480903, 16.814302829553995, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(line7, workPart.ModelingViews.WorkView, point14)
    
    point1_22 = NXOpen.Point3d(41.827871795480903, 58.500000000000014, 0.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    point1_23 = NXOpen.Point3d(41.827871795480903, -58.5, 0.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_24 = NXOpen.Point3d(60.0, -1.4210854715202004e-13, 0.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line1, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(41.827871795480903, 16.814302829553995, 0.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(60.0, -1.4210854715202004e-13, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line1, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(41.827871795480903, 16.814302829553995, 0.0)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(60.0, -1.4210854715202004e-13, 0.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line1, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point15 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point15
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point16 = NXOpen.Point3d(48.96796964396431, 80.826648689435103, 0.0)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point16)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = False
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject6 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.SetUndoMarkName(markId33, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId33, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId35, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    expression22 = workPart.Expressions.FindObject("p14")
    expression22.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId35, "Edit Driving Value")
    
    sketchRapidDimensionBuilder5.Destroy()
    
    theSession.UndoToMark(markId37, None)
    
    theSession.DeleteUndoMark(markId37, None)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    # ----------------------------------------------
    #   功能表：插入(S)->設計特徵(E)->拉伸(X)...
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit3)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("-10")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId38, "拉伸 對話方塊")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves2 = [NXOpen.ICurve.Null] * 4 
    curves2[0] = line8
    curves2[1] = line6
    curves2[2] = line7
    curves2[3] = line5
    seedPoint2 = NXOpen.Point3d(-19.500000000000011, -19.499999999999996, 0.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves2, seedPoint2, 0.01)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule2
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId39, None)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId41, None)
    
    direction3 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction3
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies4[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId40, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.88466086610904293
    rotMatrix4.Xy = 0.46122708671779233
    rotMatrix4.Xz = -0.068152229992981081
    rotMatrix4.Yx = 0.073859465754620698
    rotMatrix4.Yy = 0.0056900340105032199
    rotMatrix4.Yz = 0.99725242683655635
    rotMatrix4.Zx = 0.46034762005862473
    rotMatrix4.Zy = -0.88726388295184111
    rotMatrix4.Zz = -0.029032235800614481
    translation4 = NXOpen.Point3d(3.6372021804826722, -2.3854771021070151, -14.440139644206933)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.89692984317447444)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("-4")
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId43, None)
    
    theSession.SetUndoMarkName(markId38, "拉伸")
    
    expression25 = extrudeBuilder2.Limits.StartExtend.Value
    expression26 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression23)
    
    workPart.Expressions.Delete(expression24)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.70332811785281346
    rotMatrix5.Xy = 0.60629057200384306
    rotMatrix5.Xz = -0.37113515184750973
    rotMatrix5.Yx = -0.039033241307103381
    rotMatrix5.Yy = 0.55423969130605766
    rotMatrix5.Yz = 0.83144138136974388
    rotMatrix5.Zx = 0.70979290269111739
    rotMatrix5.Zy = -0.57028949392411321
    rotMatrix5.Zz = 0.41347784512486152
    translation5 = NXOpen.Point3d(2.1222875712100295, -3.2145323294410781, -12.227589239579558)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 0.89692984317447444)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.95342131799363461
    rotMatrix6.Xy = 0.19543409165011963
    rotMatrix6.Xz = 0.22976793992238875
    rotMatrix6.Yx = -0.21564015391150282
    rotMatrix6.Yy = -0.091024632417795029
    rotMatrix6.Yz = 0.97222108612919467
    rotMatrix6.Zx = 0.2109196871235807
    rotMatrix6.Zy = -0.97648350324729205
    rotMatrix6.Zz = -0.044641387406672055
    translation6 = NXOpen.Point3d(5.1268030300595235, -2.510633805643824, -14.518185402237227)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 0.89692984317447444)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖(H)...
    # ----------------------------------------------
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane6
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId45, "建立草圖 對話方塊")
    
    direction4 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane2 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction4, point4, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem2
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin7, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane7.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = datumPlane2
    plane7.SetGeometry(geom5)
    
    plane7.SetFlip(True)
    
    plane7.SetExpression(None)
    
    plane7.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane7.Evaluate()
    
    origin8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin8, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    plane8.SynchronizeToPlane(plane7)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom6 = [NXOpen.NXObject.Null] * 1 
    geom6[0] = datumPlane2
    plane8.SetGeometry(geom6)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId46, None)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject7 = sketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject7
    feature5 = sketch3.Feature
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId48)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.SetUndoMarkName(markId45, "建立草圖")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression27)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression30)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane8.DestroyPlane()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->矩形(R)...
    # ----------------------------------------------
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint1 = NXOpen.Point3d(2.6548899204559211, -15.634351753795899, 0.0)
    viewCenter1 = NXOpen.Point3d(-2.6548899204559211, 15.634351753795899, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(1.474938844697699, -18.068000847546987, 0.0)
    viewCenter2 = NXOpen.Point3d(-1.474938844697699, 18.068000847546987, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(1.1799510757581844, -14.454400678037588, 0.0)
    viewCenter3 = NXOpen.Point3d(-1.1799510757581844, 14.454400678037588, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(0.94396086060652729, -11.563520542430069, 0.0)
    viewCenter4 = NXOpen.Point3d(-0.94396086060652729, 11.563520542430069, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(0.75516868848522178, -9.2508164339440562, 0.0)
    viewCenter5 = NXOpen.Point3d(-0.75516868848522178, 9.2508164339440562, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(0.60413495078817736, -7.4006531471552437, 0.0)
    viewCenter6 = NXOpen.Point3d(-0.60413495078819024, 7.4006531471552437, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(0.48330796063052134, -5.9205225177241951, 0.0)
    viewCenter7 = NXOpen.Point3d(-0.48330796063056253, 5.9205225177241951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId50, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(-3.4418936889651519, 0.0, -10.0)
    endPoint9 = NXOpen.Point3d(3.5581063110348468, 0.0, -10.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(3.5581063110348468, 0.0, -10.0)
    endPoint10 = NXOpen.Point3d(3.5581063110348468, 0.0, -21.5)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(3.5581063110348468, 0.0, -21.5)
    endPoint11 = NXOpen.Point3d(-3.4418936889651519, 0.0, -21.5)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(-3.4418936889651519, 0.0, -21.5)
    endPoint12 = NXOpen.Point3d(-3.4418936889651519, 0.0, -10.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line9
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line10
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line10
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line11
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line11
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line12
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line12
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line9
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom7.Geometry = line9
    geom7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateHorizontalConstraint(geom7)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line9
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line10
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line10
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line11
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line11
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line12
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line12
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line9
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line9
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 130 * 150 {(-60.0000000000001,-59.9999999999999,-10)(-0.0000000000001,-60,-10)(59.9999999999999,-60.0000000000001,-10) EXTRUDE(2)}")
    conGeom2_15.Geometry = edge1
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = -3.4418936889651519
    help1.Point.Y = 0.0
    help1.Point.Z = -10.0
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_15, conGeom2_15, help1)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line9
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line9
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(0.058106311034847424, 0.0, -13.288016362084996)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression31 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line10
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line10
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(0.27008994894985205, 0.0, -15.75)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression32 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    expression33 = workPart.Expressions.CreateSystemExpression("6")
    
    expression34 = workPart.Expressions.CreateSystemExpression("10")
    
    workPart.Expressions.Edit(expression33, "22")
    
    workPart.Expressions.Edit(expression34, "10")
    
    workPart.Expressions.Edit(expression33, "6")
    
    workPart.Expressions.Edit(expression34, "10")
    
    workPart.Expressions.Edit(expression33, "6")
    
    workPart.Expressions.Edit(expression34, "10")
    
    workPart.Expressions.Edit(expression33, "6")
    
    workPart.Expressions.Edit(expression34, "10")
    
    theSession.SetUndoMarkVisibility(markId51, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(56.101647060718463, 0.0, -10.0)
    endPoint13 = NXOpen.Point3d(50.101647060718463, 0.0, -10.0)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(50.101647060718463, 0.0, -10.0)
    endPoint14 = NXOpen.Point3d(50.101647060718463, 0.0, -20.0)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(50.101647060718463, 0.0, -20.0)
    endPoint15 = NXOpen.Point3d(56.101647060718463, 0.0, -20.0)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(56.101647060718463, 0.0, -20.0)
    endPoint16 = NXOpen.Point3d(56.101647060718463, 0.0, -10.0)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line13
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line14
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line14
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line15
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line15
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line16
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line16
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line13
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom8.Geometry = line13
    geom8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateHorizontalConstraint(geom8)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line13
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line14
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line14
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line15
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line15
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = line16
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_18, conGeom2_18)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line16
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line13
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line13
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = edge1
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 56.101647060718463
    help2.Point.Y = 0.0
    help2.Point.Z = -10.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_20, conGeom2_20, help2)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line13
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line13
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(53.101647060718463, 0.0, -6.7119836379150053)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_9, dimOrigin9, expression33, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = line14
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line14
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(46.813630698633467, 0.0, -15.0)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_10, dimObject2_10, dimOrigin10, expression34, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖約束(K)->尺寸(D)->快速(P)...
    # ----------------------------------------------
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines25 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines28)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines29 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines32)
    
    theSession.SetUndoMarkName(markId52, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Destroy()
    
    theSession.UndoToMark(markId52, None)
    
    theSession.DeleteUndoMark(markId52, None)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension1 = dimension7
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension1)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId53, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits193 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits195 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits197 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits199 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits203 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits207 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId54, None)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject8 = sketchLinearDimensionBuilder1.Commit()
    
    point1_29 = NXOpen.Point3d(-3.4418936889651519, 0.0, -10.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, NXOpen.View.Null, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(2.5581063110348481, 0.0, -10.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, NXOpen.View.Null, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("6")
    
    theSession.SetUndoMarkName(markId55, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId55, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId53, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject9 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.SetUndoMarkName(markId53, "線性尺寸")
    
    expression35 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkVisibility(markId53, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension2 = dimension8
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension2)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId58, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits211 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits213 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits217 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId59, None)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("10")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject10 = sketchLinearDimensionBuilder2.Commit()
    
    point1_31 = NXOpen.Point3d(2.5581063110348481, 0.0, -10.0)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, NXOpen.View.Null, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(2.5581063110348539, 0.0, -20.0)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line10, NXOpen.View.Null, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("10")
    
    theSession.SetUndoMarkName(markId60, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId60, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point17 = workPart.Points.FindObject("ENTITY 2 10")
    assocOrigin5.PointOnGeometry = point17
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point18 = NXOpen.Point3d(21.690120263823395, 0.0, -21.312370726430046)
    sketchLinearDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point18)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits229 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits235 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId61, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject11 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId63, None)
    
    theSession.SetUndoMarkName(markId58, "線性尺寸")
    
    expression36 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId62, None)
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId61, None)
    
    theSession.DeleteUndoMark(markId60, None)
    
    scaleAboutPoint8 = NXOpen.Point3d(17.399086582699741, -8.5062201070976382, 0.0)
    viewCenter8 = NXOpen.Point3d(-17.399086582699777, 8.5062201070976382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(13.996598539860694, -6.8049760856781116, 0.0)
    viewCenter9 = NXOpen.Point3d(-13.996598539860713, 6.8049760856781116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖約束(K)->尺寸(D)->快速(P)...
    # ----------------------------------------------
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines33 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines36)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines37 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines40)
    
    theSession.SetUndoMarkName(markId64, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point1_33 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point1_37 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    point1_39 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    point1_41 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    point1_42 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    point1_45 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    point1_48 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(-7.1054273576010019e-14, -60.0, 0.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(2.5581063110348508, 0.0, -15.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point19 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point19
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder7.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point20 = NXOpen.Point3d(1.4453164089309842, 0.0, -30.611215888961809)
    sketchRapidDimensionBuilder7.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point20)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.TextCentered = True
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject12 = sketchRapidDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId65, None)
    
    theSession.SetUndoMarkName(markId64, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId66, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    expression37 = workPart.Expressions.FindObject("p21")
    expression37.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId66, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId67, None)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId66, "Edit Driving Value")
    
    scaleAboutPoint10 = NXOpen.Point3d(8.5371518165780174, -15.465854740177555, 0.0)
    viewCenter10 = NXOpen.Point3d(-8.5371518165780227, 15.465854740177555, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(6.8297214532624047, -12.372683792142043, 0.0)
    viewCenter11 = NXOpen.Point3d(-6.8297214532624215, 12.372683792142043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(5.463777162609925, -9.8981470337136361, 0.0)
    viewCenter12 = NXOpen.Point3d(-5.4637771626099454, 9.8981470337136361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(4.3710217300879393, -7.9185176269709077, 0.0)
    viewCenter13 = NXOpen.Point3d(-4.3710217300879508, 7.9185176269709077, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(5.4637771626099223, -9.8981470337136308, 0.0)
    viewCenter14 = NXOpen.Point3d(-5.4637771626099294, 9.8981470337136308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(6.8297214532624038, -12.372683792142039, 0.0)
    viewCenter15 = NXOpen.Point3d(-6.8297214532624206, 12.372683792142039, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(8.5371518165780031, -15.465854740177548, 0.0)
    viewCenter16 = NXOpen.Point3d(-8.5371518165780245, 15.465854740177548, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(10.671439770722516, -19.332318425221931, 0.0)
    viewCenter17 = NXOpen.Point3d(-10.671439770722516, 19.332318425221931, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    point21 = NXOpen.Point3d(55.543540749683615, 0.0, -13.355188462608641)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(line16, workPart.ModelingViews.WorkView, point21)
    
    point1_51 = NXOpen.Point3d(55.543540749683615, 0.0, -9.9999999999999982)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line16, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(55.543540749683615, 0.0, -20.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line16, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    edge2 = extrude1.FindObject("EDGE * 150 * 160 {(59.9999999999999,-60.0000000000001,-10)(59.9999999999999,-60.0000000000001,-5)(59.9999999999999,-60.0000000000001,0) EXTRUDE(2)}")
    point1_53 = NXOpen.Point3d(59.999999999999922, -60.000000000000142, -5.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point1_54 = NXOpen.Point3d(55.543540749683615, 0.0, -13.355188462608641)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line16, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(59.999999999999922, -60.000000000000142, -5.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(55.543540749683615, 0.0, -13.355188462608641)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line16, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(59.999999999999922, -60.000000000000142, -5.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point22 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point22
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point23 = NXOpen.Point3d(59.608529623053741, 0.0, -15.191758713004706)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point23)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject13 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId69, None)
    
    theSession.SetUndoMarkName(markId68, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId68, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId70, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression38 = workPart.Expressions.FindObject("p22")
    expression38.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId71, None)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId70, "Edit Driving Value")
    
    scaleAboutPoint18 = NXOpen.Point3d(-2.1265550267744171, -13.532622897655386, 0.0)
    viewCenter18 = NXOpen.Point3d(2.1265550267744171, 13.532622897655386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-1.701244021419527, -10.826098318124309, 0.0)
    viewCenter19 = NXOpen.Point3d(1.7012440214195337, 10.826098318124309, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    theSession.UndoToMark(markId72, None)
    
    theSession.DeleteUndoMark(markId72, None)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->圓(C)...
    # ----------------------------------------------
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId74, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(1.9984014443252818e-15, 0.0, -17.008996644975582)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.4912866480002622, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = arc1
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(1.9984014443252818e-15, 0.0, -16.30755315439745)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_11, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension11 = sketchDimensionalConstraint11.AssociatedDimension
    
    expression39 = sketchDimensionalConstraint11.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   對話開始 圓
    # ----------------------------------------------
    # ----------------------------------------------
    #   功能表：插入(S)->草圖約束(K)->尺寸(D)->快速(P)...
    # ----------------------------------------------
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines53 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines56)
    
    theSession.SetUndoMarkName(markId75, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    point1_58 = NXOpen.Point3d(1.3988080011709909, 0.0, -16.492013045270639)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc1, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(1.3988080011709909, 0.0, -16.492013045270639)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    point1_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point24 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point24
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder10.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point25 = NXOpen.Point3d(5.0333947086521817, 0.0, -13.544645183175792)
    sketchRapidDimensionBuilder10.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point25)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.TextCentered = False
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject14 = sketchRapidDimensionBuilder10.Commit()
    
    theSession.DeleteUndoMark(markId76, None)
    
    theSession.SetUndoMarkName(markId75, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines57 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines60)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId77, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    expression40 = workPart.Expressions.FindObject("p23")
    expression40.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId77, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId78, None)
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId77, "Edit Driving Value")
    
    scaleAboutPoint20 = NXOpen.Point3d(-0.43304393272496844, -8.5990152355387153, 0.0)
    viewCenter20 = NXOpen.Point3d(0.43304393272497904, 8.5990152355387153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-0.54130491590621066, -10.748769044423396, 0.0)
    viewCenter21 = NXOpen.Point3d(0.54130491590621721, 10.748769044423396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-0.43304393272496844, -8.5990152355387153, 0.0)
    viewCenter22 = NXOpen.Point3d(0.43304393272497904, 8.5990152355387153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-0.34643514617997057, -6.8792121884309729, 0.0)
    viewCenter23 = NXOpen.Point3d(0.3464351461799875, 6.8792121884309729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    theSession.UndoToMark(markId79, None)
    
    theSession.DeleteUndoMark(markId79, None)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension1)
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId80, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits371 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits373 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits377 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits385 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId81, None)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    nXObject15 = sketchLinearDimensionBuilder3.Commit()
    
    point1_61 = NXOpen.Point3d(2.2204460492503131e-15, 0.0, -20.0)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line11, NXOpen.View.Null, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(1.4392694793164334e-15, 0.0, -16.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("4")
    
    theSession.SetUndoMarkName(markId82, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId82, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject16 = sketchLinearDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId84, None)
    
    theSession.SetUndoMarkName(markId80, "線性尺寸")
    
    expression41 = sketchLinearDimensionBuilder3.Driving.ExpressionValue
    sketchLinearDimensionBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId83, None)
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId82, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    perpendicularDimension2 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension2)
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId85, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits389 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits391 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits395 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits405 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId86, None)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("3")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchLinearDimensionBuilder4.Commit()
    
    point1_63 = NXOpen.Point3d(3.0000000000000009, 0.0, -15.0)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, NXOpen.View.Null, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(1.4392694793164334e-15, 0.0, -16.0)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    theSession.SetUndoMarkName(markId87, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point26 = workPart.Points.FindObject("ENTITY 2 8")
    assocOrigin9.PointOnGeometry = point26
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point27 = NXOpen.Point3d(8.8194359490476444, 0.0, -25.610486417272718)
    sketchLinearDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point27)
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder4.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits407 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits413 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId88, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject18 = sketchLinearDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.SetUndoMarkName(markId85, "線性尺寸")
    
    expression42 = sketchLinearDimensionBuilder4.Driving.ExpressionValue
    sketchLinearDimensionBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId88, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    scaleAboutPoint24 = NXOpen.Point3d(8.3540360964543243, -12.70922079128832, 0.0)
    viewCenter24 = NXOpen.Point3d(-8.3540360964543066, 12.70922079128832, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(6.6832288771634554, -10.167376633030655, 0.0)
    viewCenter25 = NXOpen.Point3d(-6.6832288771634447, 10.167376633030655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(5.3465831017307686, -8.1339013064245229, 0.0)
    viewCenter26 = NXOpen.Point3d(-5.3465831017307561, 8.1339013064245229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(4.2772664813846193, -6.5071210451396206, 0.0)
    viewCenter27 = NXOpen.Point3d(-4.2772664813846024, 6.5071210451396206, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(3.4218131851076934, -5.2056968361117004, 0.0)
    viewCenter28 = NXOpen.Point3d(-3.4218131851076792, 5.2056968361116889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(2.7374505480861542, -4.1645574688893596, 0.0)
    viewCenter29 = NXOpen.Point3d(-2.7374505480861431, 4.1645574688893507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(3.4218131851076934, -5.2056968361117004, 0.0)
    viewCenter30 = NXOpen.Point3d(-3.4218131851076792, 5.2056968361116889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(4.2772664813846166, -6.5071210451396189, 0.0)
    viewCenter31 = NXOpen.Point3d(-4.2772664813845998, 6.5071210451396189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(5.3465831017307686, -8.1339013064245229, 0.0)
    viewCenter32 = NXOpen.Point3d(-5.3465831017307517, 8.1339013064245229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(6.6832288771634554, -10.167376633030655, 0.0)
    viewCenter33 = NXOpen.Point3d(-6.6832288771634394, 10.167376633030655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(5.3465831017307686, -8.1339013064245229, 0.0)
    viewCenter34 = NXOpen.Point3d(-5.3465831017307517, 8.1339013064245229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(6.6832288771634554, -10.167376633030655, 0.0)
    viewCenter35 = NXOpen.Point3d(-6.6832288771634447, 10.167376633030655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(8.354036096454319, -12.709220791288317, 0.0)
    viewCenter36 = NXOpen.Point3d(-8.3540360964543048, 12.709220791288317, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(10.442545120567894, -15.886525989110396, 0.0)
    viewCenter37 = NXOpen.Point3d(-10.442545120567885, 15.886525989110396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(13.795542428238388, -19.672567229505862, 0.0)
    viewCenter38 = NXOpen.Point3d(-13.795542428238377, 19.672567229505862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(17.244428035297975, -24.59070903688232, 0.0)
    viewCenter39 = NXOpen.Point3d(-17.244428035297961, 24.59070903688232, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(21.555535044122486, -30.738386296102902, 0.0)
    viewCenter40 = NXOpen.Point3d(-21.555535044122454, 30.738386296102902, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(26.944418805153095, -38.422982870128628, 0.0)
    viewCenter41 = NXOpen.Point3d(-26.944418805153074, 38.422982870128628, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(79.594779766343493, -39.570839276626145, 0.0)
    viewCenter42 = NXOpen.Point3d(-79.594779766343464, 39.570839276626145, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(63.675823813074821, -31.656671421300921, 0.0)
    viewCenter43 = NXOpen.Point3d(-63.675823813074764, 31.656671421300921, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(50.843997458333767, -26.001968281923546, 0.0)
    viewCenter44 = NXOpen.Point3d(-50.843997458333682, 26.001968281923546, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(38.819295397845714, -20.878903899239706, 0.0)
    viewCenter45 = NXOpen.Point3d(-38.819295397845622, 20.878903899239706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(31.055436318276588, -16.703123119391766, 0.0)
    viewCenter46 = NXOpen.Point3d(-31.055436318276492, 16.703123119391766, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(24.794858319452704, -13.36249849551341, 0.0)
    viewCenter47 = NXOpen.Point3d(-24.794858319452619, 13.36249849551341, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->圓(C)...
    # ----------------------------------------------
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression43 = workPart.Expressions.CreateSystemExpression("3")
    
    theSession.SetUndoMarkVisibility(markId92, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(52.999999999999929, 0.0, -16.176856330680309)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.5, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = arc2
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(52.999999999999929, 0.0, -15.727932496710304)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_12, dimOrigin12, expression43, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension12 = sketchDimensionalConstraint12.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId93, "Curve")
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension3)
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId94, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits419 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits421 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits425 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits431 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject19 = sketchLinearDimensionBuilder5.Commit()
    
    point1_65 = NXOpen.Point3d(52.999999999999929, 0.0, -20.0)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line15, NXOpen.View.Null, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    point1_66 = NXOpen.Point3d(52.999999999999929, 0.0, -16.0)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("4")
    
    theSession.SetUndoMarkName(markId96, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject20 = sketchLinearDimensionBuilder5.Commit()
    
    point1_67 = NXOpen.Point3d(52.999999999999929, 0.0, -20.0)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line15, NXOpen.View.Null, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    point1_68 = NXOpen.Point3d(52.999999999999929, 0.0, -16.0)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    theSession.SetUndoMarkName(markId97, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId97, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point28 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point28
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point29 = NXOpen.Point3d(41.121110842287727, 0.0, -15.899708213736311)
    sketchLinearDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point29)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits437 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits441 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits443 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits447 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId98, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId98, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    scaleAboutPoint48 = NXOpen.Point3d(12.154924557400388, -13.263517025176284, 0.0)
    viewCenter48 = NXOpen.Point3d(-12.154924557400301, 13.263517025176284, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(9.7239396459203196, -10.610813620141027, 0.0)
    viewCenter49 = NXOpen.Point3d(-9.7239396459202325, 10.610813620141027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(7.7791517167362612, -8.4886508961128211, 0.0)
    viewCenter50 = NXOpen.Point3d(-7.7791517167361786, 8.4886508961128211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(6.2233213733890294, -6.7909207168902581, 0.0)
    viewCenter51 = NXOpen.Point3d(-6.223321373388929, 6.7909207168902581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(7.7791517167362647, -8.4886508961128211, 0.0)
    viewCenter52 = NXOpen.Point3d(-7.7791517167361661, 8.4886508961128211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(9.7239396459203267, -10.610813620141027, 0.0)
    viewCenter53 = NXOpen.Point3d(-9.7239396459202272, 10.610813620141027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(12.154924557400395, -13.263517025176284, 0.0)
    viewCenter54 = NXOpen.Point3d(-12.154924557400294, 13.263517025176284, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    # ----------------------------------------------
    #   功能表：插入(S)->設計特徵(E)->拉伸(X)...
    # ----------------------------------------------
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject21 = sketchLinearDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.SetUndoMarkName(markId94, "線性尺寸")
    
    expression44 = sketchLinearDimensionBuilder5.Driving.ExpressionValue
    sketchLinearDimensionBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId99, None)
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId98, None)
    
    theSession.DeleteUndoMark(markId97, None)
    
    theSession.DeleteUndoMark(markId96, None)
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit3)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("-4")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId101, "拉伸 對話方塊")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves3 = [NXOpen.ICurve.Null] * 10 
    curves3[0] = arc2
    curves3[1] = line9
    curves3[2] = line11
    curves3[3] = arc1
    curves3[4] = line15
    curves3[5] = line13
    curves3[6] = line10
    curves3[7] = line12
    curves3[8] = line14
    curves3[9] = line16
    seedPoint3 = NXOpen.Point3d(52.999999999999929, 0.0, -11.499999999999998)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves3, seedPoint3, 0.01)
    
    curves4 = [NXOpen.ICurve.Null] * 10 
    curves4[0] = arc2
    curves4[1] = line9
    curves4[2] = line11
    curves4[3] = arc1
    curves4[4] = line15
    curves4[5] = line13
    curves4[6] = line10
    curves4[7] = line12
    curves4[8] = line14
    curves4[9] = line16
    seedPoint4 = NXOpen.Point3d(-1.5000000000000013, 0.0, -13.499999999999998)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves4, seedPoint4, 0.01)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 2 
    rules3[0] = regionBoundaryRule3
    rules3[1] = regionBoundaryRule4
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId104, None)
    
    direction5 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction5
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId103, None)
    
    scaleAboutPoint55 = NXOpen.Point3d(-11.135415412927792, -9.1557860061851262, 0.0)
    viewCenter55 = NXOpen.Point3d(11.135415412927902, 9.1557860061851262, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(-8.9083323303422208, -7.3246288049481008, 0.0)
    viewCenter56 = NXOpen.Point3d(8.9083323303423274, 7.3246288049481008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(-7.1266658642737655, -5.859703043958481, 0.0)
    viewCenter57 = NXOpen.Point3d(7.1266658642738676, 5.859703043958481, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(-5.7013326914190046, -4.6877624351667837, 0.0)
    viewCenter58 = NXOpen.Point3d(5.7013326914191023, 4.6877624351667837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(-4.5610661531351919, -3.7502099481334135, 0.0)
    viewCenter59 = NXOpen.Point3d(4.5610661531352958, 3.7502099481334414, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(-5.7013326914190028, -4.6877624351667668, 0.0)
    viewCenter60 = NXOpen.Point3d(5.7013326914191067, 4.6877624351668015, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(-7.1266658642737681, -5.8597030439584792, 0.0)
    viewCenter61 = NXOpen.Point3d(7.1266658642738658, 5.8597030439584792, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(-8.9083323303422173, -7.3246288049480981, 0.0)
    viewCenter62 = NXOpen.Point3d(8.9083323303423185, 7.3246288049480981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(-11.135415412927786, -9.1557860061851226, 0.0)
    viewCenter63 = NXOpen.Point3d(11.135415412927888, 9.1557860061851226, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(-13.919269266159747, -11.444732507731404, 0.0)
    viewCenter64 = NXOpen.Point3d(13.919269266159841, 11.444732507731404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    extrudeBuilder3.Limits.SymmetricOption = True
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("-4")
    
    extrudeBuilder3.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder3.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder3.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature6 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId101, "拉伸")
    
    expression50 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression45)
    
    workPart.Expressions.Delete(expression46)
    
    workPart.Expressions.Delete(expression47)
    
    workPart.Expressions.Delete(expression48)
    
    workPart.Expressions.Delete(expression49)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.71925268233317041
    rotMatrix7.Xy = 0.6947483677093087
    rotMatrix7.Xz = 0.00053340584025433056
    rotMatrix7.Yx = 0.0076319586872452593
    rotMatrix7.Yy = -0.0086688609850135018
    rotMatrix7.Yz = 0.99993329980345125
    rotMatrix7.Zx = 0.69470665187770841
    rotMatrix7.Zy = -0.71920063710655457
    rotMatrix7.Zz = -0.011537392356632852
    translation7 = NXOpen.Point3d(-37.37242130257254, -2.5838924711202953, -0.11537392356632853)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 3.4215158202151308)
    
    scaleAboutPoint65 = NXOpen.Point3d(23.198782110266389, -17.167098761597085, 0.0)
    viewCenter65 = NXOpen.Point3d(-23.198782110266279, 17.167098761597085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(18.559025688213122, -13.733679009277669, 0.0)
    viewCenter66 = NXOpen.Point3d(-18.559025688213012, 13.733679009277669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(14.847220550570505, -10.986943207422133, 0.0)
    viewCenter67 = NXOpen.Point3d(-14.847220550570395, 10.986943207422133, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(10.254480326927366, -9.0667026828816493, 0.0)
    viewCenter68 = NXOpen.Point3d(-10.25448032692727, 9.0667026828817026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(12.62013746798492, -11.2838876184335, 0.0)
    viewCenter69 = NXOpen.Point3d(-12.620137467984831, 11.283887618433567, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(15.280264483295449, -13.919269266159745, 0.0)
    viewCenter70 = NXOpen.Point3d(-15.280264483295365, 13.919269266159828, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint70, viewCenter70)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.52182498884652506
    rotMatrix8.Xy = 0.85296924309958655
    rotMatrix8.Xz = 0.011922723742610638
    rotMatrix8.Yx = 0.10108302629546551
    rotMatrix8.Yy = -0.075706026138725319
    rotMatrix8.Yz = 0.99199335653079501
    rotMatrix8.Zx = 0.84704244451519317
    rotMatrix8.Zy = -0.51644173720992126
    rotMatrix8.Zz = -0.1257260086749139
    translation8 = NXOpen.Point3d(-39.040813223807035, -2.8532126000561924, -1.257260086749139)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 3.4215158202151317)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖(H)...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin9, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane9
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId108, "建立草圖 對話方塊")
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature6
    edge3 = extrude2.FindObject("EDGE * 140 * 230 {(55.9999999999999,5,-20)(55.9999999999999,5,-15)(55.9999999999999,5,-10) EXTRUDE(2)}")
    point30 = workPart.Points.CreatePoint(edge3, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge4 = extrude1.FindObject("EDGE * 130 EXTRUDE(6) 230 {(55.9999999999999,-5,-10)(55.9999999999999,0,-10)(55.9999999999999,5,-10) EXTRUDE(2)}")
    direction6 = workPart.Directions.CreateDirection(edge4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude2.FindObject("FACE 230 {(55.9999999999999,0,-15) EXTRUDE(2)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction6, point30, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem3
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin10, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane10.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = face1
    plane10.SetGeometry(geom9)
    
    plane10.SetFlip(False)
    
    plane10.SetExpression(None)
    
    plane10.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane10.Evaluate()
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin11, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    plane11.SynchronizeToPlane(plane10)
    
    scalar2 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point31 = workPart.Points.CreatePoint(edge3, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face1
    plane11.SetGeometry(geom10)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    face2 = extrude2.FindObject("FACE 250 {(52.9999999999999,0,-17.5) EXTRUDE(2)}")
    line17 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    line17.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = line17
    nErrs4 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    theSession.DeleteUndoMark(markId109, None)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject22 = sketchInPlaceBuilder4.Commit()
    
    sketch4 = nXObject22
    feature7 = sketch4.Feature
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId111)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId110, None)
    
    theSession.SetUndoMarkName(markId108, "建立草圖")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression52)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point31)
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression51)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression54)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression53)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane11.DestroyPlane()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->矩形(R)...
    # ----------------------------------------------
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint71 = NXOpen.Point3d(-7.9649151911913849, -7.1142931804816882, 0.0)
    viewCenter71 = NXOpen.Point3d(7.9649151911914773, 7.1142931804816882, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-5.5677077064638683, -6.3100687339924377, 0.0)
    viewCenter72 = NXOpen.Point3d(5.5677077064639633, 6.3100687339924795, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-4.3056939596653772, -5.1965271926996213, 0.0)
    viewCenter73 = NXOpen.Point3d(4.3056939596654784, 5.1965271926996888, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId113, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(55.999999999999929, -1.6162926578479144, -10.0)
    endPoint17 = NXOpen.Point3d(55.999999999999929, 1.7886699217495754, -10.0)
    line18 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(55.999999999999929, 1.7886699217495754, -10.0)
    endPoint18 = NXOpen.Point3d(55.999999999999929, 1.7886699217495754, -19.999999999999996)
    line19 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(55.999999999999929, 1.7886699217495754, -19.999999999999996)
    endPoint19 = NXOpen.Point3d(55.999999999999929, -1.6162926578479144, -19.999999999999996)
    line20 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(55.999999999999929, -1.6162926578479144, -19.999999999999996)
    endPoint20 = NXOpen.Point3d(55.999999999999929, -1.6162926578479144, -10.0)
    line21 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line21, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line18
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line19
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line19
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line20
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line20
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line21
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line21
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line18
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom11.Geometry = line18
    geom11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateHorizontalConstraint(geom11)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line18
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = line19
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint43 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_21, conGeom2_21)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line19
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_22.Geometry = line20
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_22, conGeom2_22)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line20
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = line21
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint45 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_23, conGeom2_23)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line21
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line18
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line18
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    edge5 = extrude1.FindObject("EDGE * 130 * 160 {(59.9999999999999,-60.0000000000001,-10)(60,-0.0000000000001,-10)(60.0000000000001,59.9999999999999,-10) EXTRUDE(2)}")
    conGeom2_25.Geometry = edge5
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 55.999999999999929
    help3.Point.Y = -1.6162926578479144
    help3.Point.Z = -10.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_25, conGeom2_25, help3)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line20
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    edge6 = extrude2.FindObject("EDGE * 220 * 230 {(55.9999999999999,-5,-20)(55.9999999999999,0,-20)(55.9999999999999,5,-20) EXTRUDE(2)}")
    conGeom2_26.Geometry = edge6
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = 55.999999999999929
    help4.Point.Y = 1.7886699217495767
    help4.Point.Z = -20.0
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_26, conGeom2_26, help4)
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = line19
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line19
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(55.999999999999929, 0.44189841983956324, -14.999999999999998)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_13, dimObject2_11, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint13
    dimension13 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression55 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line18
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line18
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(55.999999999999929, 0.086188631950830485, -11.346771501910013)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_12, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression56 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line18
    geoms9[1] = line19
    geoms9[2] = line20
    geoms9[3] = line21
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line18
    geoms10[1] = line19
    geoms10[2] = line20
    geoms10[3] = line21
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    scaleAboutPoint74 = NXOpen.Point3d(-1.1085924677758767, 2.2963701118215929, 0.0)
    viewCenter74 = NXOpen.Point3d(1.1085924677759746, -2.2963701118215525, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-0.88687397422069059, 1.8370960894572745, 0.0)
    viewCenter75 = NXOpen.Point3d(0.88687397422079051, -1.8370960894572421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-0.70949917937654394, 1.469676871565837, 0.0)
    viewCenter76 = NXOpen.Point3d(0.7094991793766412, -1.4696768715657766, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension3 = dimension14
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension3)
    
    sketchLinearDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId114, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits449 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder6.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits451 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits455 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits461 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits463 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId115, None)
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder6.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder6.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    nXObject23 = sketchLinearDimensionBuilder6.Commit()
    
    point1_69 = NXOpen.Point3d(55.999999999999929, -4.211330078250425, -10.0)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line18, NXOpen.View.Null, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    point1_70 = NXOpen.Point3d(55.999999999999929, 1.788669921749575, -10.0)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line18, NXOpen.View.Null, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    sketchLinearDimensionBuilder6.Driving.ExpressionValue.SetFormula("6")
    
    theSession.SetUndoMarkName(markId116, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId116, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId114, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject24 = sketchLinearDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId118, None)
    
    theSession.SetUndoMarkName(markId114, "線性尺寸")
    
    expression57 = sketchLinearDimensionBuilder6.Driving.ExpressionValue
    sketchLinearDimensionBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId117, None)
    
    theSession.SetUndoMarkVisibility(markId114, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId116, None)
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    perpendicularDimension4 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension4)
    
    sketchLinearDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId119, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits467 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder7.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits469 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits473 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits477 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId120, None)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder7.Driving.ExpressionValue.SetFormula("2")
    
    sketchLinearDimensionBuilder7.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    nXObject25 = sketchLinearDimensionBuilder7.Commit()
    
    taggedObject1 = sketchLinearDimensionBuilder7.FirstAssociativity.Value
    
    line22 = taggedObject1
    point1_71 = NXOpen.Point3d(55.999999999999929, 5.0, 4.2875000000000014)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line22, NXOpen.View.Null, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(55.999999999999929, 3.0, -10.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line18, NXOpen.View.Null, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    sketchLinearDimensionBuilder7.Driving.ExpressionValue.SetFormula("2")
    
    theSession.SetUndoMarkName(markId121, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId119, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject26 = sketchLinearDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId123, None)
    
    theSession.SetUndoMarkName(markId119, "線性尺寸")
    
    expression58 = sketchLinearDimensionBuilder7.Driving.ExpressionValue
    sketchLinearDimensionBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId122, None)
    
    theSession.SetUndoMarkVisibility(markId119, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId121, None)
    
    # ----------------------------------------------
    #   功能表：插入(S)->設計特徵(E)->拉伸(X)...
    # ----------------------------------------------
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit3)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId124, "拉伸 對話方塊")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves5 = [NXOpen.ICurve.Null] * 4 
    curves5[0] = line21
    curves5[1] = line19
    curves5[2] = line20
    curves5[3] = line18
    seedPoint5 = NXOpen.Point3d(55.999999999999929, -0.99999999999999822, -13.333333333333334)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves5, seedPoint5, 0.01)
    
    section4.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = regionBoundaryRule5
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId125, None)
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId127, None)
    
    direction7 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction7
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId126, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("-100")
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId128, None)
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature8 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId129, None)
    
    theSession.SetUndoMarkName(markId124, "拉伸")
    
    expression61 = extrudeBuilder4.Limits.StartExtend.Value
    expression62 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression59)
    
    workPart.Expressions.Delete(expression60)
    
    scaleAboutPoint77 = NXOpen.Point3d(-10.115431157397664, -2.8177253123812944, 0.0)
    viewCenter77 = NXOpen.Point3d(10.115431157397762, 2.8177253123813495, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-8.0923449259181215, -2.2541802499050245, 0.0)
    viewCenter78 = NXOpen.Point3d(8.0923449259182174, 2.2541802499050907, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-6.4738759407344864, -1.8033441999240107, 0.0)
    viewCenter79 = NXOpen.Point3d(6.4738759407345849, 1.8033441999240816, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-8.0923449259181197, -2.2541802499050241, 0.0)
    viewCenter80 = NXOpen.Point3d(8.092344925918221, 2.2541802499050902, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-10.095159752272616, -2.7974539072562528, 0.0)
    viewCenter81 = NXOpen.Point3d(10.095159752272712, 2.7974539072563083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-12.618949690340777, -3.4968173840703156, 0.0)
    viewCenter82 = NXOpen.Point3d(12.618949690340877, 3.4968173840703849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-15.773687112925979, -4.371021730087894, 0.0)
    viewCenter83 = NXOpen.Point3d(15.773687112926087, 4.3710217300879801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.90763993707029933
    rotMatrix9.Xy = 0.41971624367633409
    rotMatrix9.Xz = -0.0052933381954815353
    rotMatrix9.Yx = 0.018780264234727614
    rotMatrix9.Yy = -0.028007946626279923
    rotMatrix9.Yz = 0.99943126657167036
    rotMatrix9.Zx = 0.41932928148448839
    rotMatrix9.Zy = -0.90722314218719613
    rotMatrix9.Zz = -0.033303512873193879
    translation9 = NXOpen.Point3d(-10.566226025100871, 9.9315386172289735, -56.333035128731943)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 6.6826480863576805)
    
    scaleAboutPoint84 = NXOpen.Point3d(-16.074590782750878, -5.0282586931264861, 0.0)
    viewCenter84 = NXOpen.Point3d(16.074590782750981, 5.0282586931265403, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-12.859672626200689, -4.0226069545011676, 0.0)
    viewCenter85 = NXOpen.Point3d(12.859672626200798, 4.0226069545012537, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-10.287738100960542, -3.2180855636009342, 0.0)
    viewCenter86 = NXOpen.Point3d(10.287738100960649, 3.2180855636010035, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-8.2301904807684245, -2.5744684508807474, 0.0)
    viewCenter87 = NXOpen.Point3d(8.2301904807685329, 2.5744684508808025, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-6.5841523846147281, -2.0595747607045864, 0.0)
    viewCenter88 = NXOpen.Point3d(6.5841523846148364, 2.0595747607046531, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-5.3192167048118861, -1.6476598085636602, 0.0)
    viewCenter89 = NXOpen.Point3d(5.3192167048119963, 1.6476598085637311, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-6.6490208810148701, -2.0595747607045864, 0.0)
    viewCenter90 = NXOpen.Point3d(6.6490208810149838, 2.0595747607046531, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-8.3112761012686001, -2.5744684508807465, 0.0)
    viewCenter91 = NXOpen.Point3d(8.3112761012687137, 2.574468450880802, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-10.43977363939838, -3.2180855636009338, 0.0)
    viewCenter92 = NXOpen.Point3d(10.439773639398492, 3.2180855636010026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(-13.04971704924799, -4.0226069545011676, 0.0)
    viewCenter93 = NXOpen.Point3d(13.0497170492481, 4.0226069545012537, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-16.312146311559999, -5.0282586931264861, 0.0)
    viewCenter94 = NXOpen.Point3d(16.31214631156011, 5.0282586931265403, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-20.390182889450017, -6.2853233664081065, 0.0)
    viewCenter95 = NXOpen.Point3d(20.390182889450116, 6.285323366408174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-25.487728611812539, -7.8566542080101334, 0.0)
    viewCenter96 = NXOpen.Point3d(25.487728611812631, 7.8566542080102177, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-31.859660764765682, -9.820817760012666, 0.0)
    viewCenter97 = NXOpen.Point3d(31.859660764765774, 9.8208177600127708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-39.824575955957116, -12.276022200015834, 0.0)
    viewCenter98 = NXOpen.Point3d(39.824575955957236, 12.276022200015966, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint98, viewCenter98)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.117191485814162
    rotMatrix10.Xy = -0.99307192383091647
    rotMatrix10.Xz = -0.0086203104026550004
    rotMatrix10.Yx = 0.030057415004861032
    rotMatrix10.Yy = -0.01222292575360793
    rotMatrix10.Yz = 0.9994734373104911
    rotMatrix10.Zx = -0.99265437462185147
    rotMatrix10.Zy = 0.11687067290296149
    rotMatrix10.Zz = 0.03128159777432285
    translation10 = NXOpen.Point3d(-44.203051599435383, -0.38480873227612911, -55.687184022256787)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 2.1897701249376857)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = -0.030696087569291271
    rotMatrix11.Xy = -0.99948793324189122
    rotMatrix11.Xz = -0.0090344624521176888
    rotMatrix11.Yx = 0.1335983511098783
    rotMatrix11.Yy = -0.013060330480970821
    rotMatrix11.Yz = 0.99094949838447921
    rotMatrix11.Zx = -0.99056005915273282
    rotMatrix11.Zy = 0.029211283292388743
    rotMatrix11.Zz = 0.13393084088346374
    translation11 = NXOpen.Point3d(-44.207193119930011, -0.47004812153624798, -54.660691591165374)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 2.1897701249376857)
    
    scaleAboutPoint99 = NXOpen.Point3d(-30.931709480355025, -28.031861716571758, 0.0)
    viewCenter99 = NXOpen.Point3d(30.931709480355128, 28.031861716571758, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-24.842029176410129, -22.425489373257346, 0.0)
    viewCenter100 = NXOpen.Point3d(24.842029176410243, 22.425489373257477, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-19.873623341128081, -17.940391498605873, 0.0)
    viewCenter101 = NXOpen.Point3d(19.873623341128191, 17.94039149860598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-20.043747743270035, -12.372683792142, 0.0)
    viewCenter102 = NXOpen.Point3d(20.043747743270149, 12.372683792142086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-25.132013952788444, -15.388525466476578, 0.0)
    viewCenter103 = NXOpen.Point3d(25.132013952788562, 15.388525466476683, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-31.801663809490009, -18.655687280339063, 0.0)
    viewCenter104 = NXOpen.Point3d(31.801663809490126, 18.655687280339194, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-39.752079761862511, -23.319609100423829, 0.0)
    viewCenter105 = NXOpen.Point3d(39.752079761862618, 23.319609100423992, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-49.690099702328162, -29.149511375529887, 0.0)
    viewCenter106 = NXOpen.Point3d(49.69009970232824, 29.149511375529887, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-62.112624627910215, -36.436889219412357, 0.0)
    viewCenter107 = NXOpen.Point3d(62.112624627910314, 36.436889219412357, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint107, viewCenter107)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.055429633289932709
    rotMatrix12.Xy = -0.99830620278140958
    rotMatrix12.Xz = -0.017671481022108051
    rotMatrix12.Yx = 0.064668823103358752
    rotMatrix12.Yy = -0.014072003288302137
    rotMatrix12.Yz = 0.9978075576191443
    rotMatrix12.Zx = -0.99636614709241111
    rotMatrix12.Zy = -0.056450900892945105
    rotMatrix12.Zz = 0.063779281248731057
    translation12 = NXOpen.Point3d(-86.297148305463622, -20.552645570083413, -55.362207187512702)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 1.1211623039680956)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖(H)...
    # ----------------------------------------------
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin12, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane12
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId131, "建立草圖 對話方塊")
    
    datumAxis4 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    direction8 = workPart.Directions.CreateDirection(datumAxis4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane3 = workPart.Datums.FindObject("DATUM_CSYS(0) YZ plane")
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane3, direction8, point4, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem4
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin13, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane13.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = datumPlane3
    plane13.SetGeometry(geom12)
    
    plane13.SetFlip(False)
    
    plane13.SetExpression(None)
    
    plane13.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane13.Evaluate()
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin14, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    plane14.SynchronizeToPlane(plane13)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = datumPlane3
    plane14.SetGeometry(geom13)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId132, None)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject27 = sketchInPlaceBuilder5.Commit()
    
    sketch5 = nXObject27
    feature9 = sketch5.Feature
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId134)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId133, None)
    
    theSession.SetUndoMarkName(markId131, "建立草圖")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression64)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression63)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression66)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression65)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane14.DestroyPlane()
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = -0.14392120154622107
    rotMatrix13.Xy = -0.98958842607862918
    rotMatrix13.Xz = -0.0011977966080628966
    rotMatrix13.Yx = 0.033925073121675461
    rotMatrix13.Yy = -0.0061435862014782763
    rotMatrix13.Yz = 0.99940549616373131
    rotMatrix13.Zx = -0.98900747072971162
    rotMatrix13.Zy = 0.14379500450226793
    rotMatrix13.Zz = 0.034456052023000762
    translation13 = NXOpen.Point3d(-0.011977966080628965, -0.0059450383626860059, 0.34456052023000761)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 1.1211623039680954)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->矩形(R)...
    # ----------------------------------------------
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint108 = NXOpen.Point3d(-30.206747539409193, -21.947090009102027, 0.0)
    viewCenter108 = NXOpen.Point3d(30.206747539409292, 21.947090009102027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(-24.920566720012577, -16.236126802432508, 0.0)
    viewCenter109 = NXOpen.Point3d(24.920566720012673, 16.236126802432508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-26.128836621588952, -6.0413495078818142, 0.0)
    viewCenter110 = NXOpen.Point3d(26.128836621589056, 6.0413495078818142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-20.903069297271141, -4.8330796063053691, 0.0)
    viewCenter111 = NXOpen.Point3d(20.903069297271244, 4.8330796063055343, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId136, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint21 = NXOpen.Point3d(0.0, 43.24344073346743, -10.0)
    endPoint21 = NXOpen.Point3d(0.0, 39.24344073346743, -10.0)
    line23 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    startPoint22 = NXOpen.Point3d(0.0, 39.24344073346743, -10.0)
    endPoint22 = NXOpen.Point3d(0.0, 39.24344073346743, -20.0)
    line24 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(0.0, 39.24344073346743, -20.0)
    endPoint23 = NXOpen.Point3d(0.0, 43.24344073346743, -20.0)
    line25 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(0.0, 43.24344073346743, -20.0)
    endPoint24 = NXOpen.Point3d(0.0, 43.24344073346743, -10.0)
    line26 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line23
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line24
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line24
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = line25
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line25
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = line26
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line26
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line23
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint50 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom14.Geometry = line23
    geom14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint51 = theSession.ActiveSketch.CreateHorizontalConstraint(geom14)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line23
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_27.Geometry = line24
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint52 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_27, conGeom2_27)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line24
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_28.Geometry = line25
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint53 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_28, conGeom2_28)
    
    conGeom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_29.Geometry = line25
    conGeom1_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_29.SplineDefiningPointIndex = 0
    conGeom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_29.Geometry = line26
    conGeom2_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint54 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_29, conGeom2_29)
    
    conGeom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_30.Geometry = line26
    conGeom1_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_30.SplineDefiningPointIndex = 0
    conGeom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_30.Geometry = line23
    conGeom2_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint55 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_30, conGeom2_30)
    
    conGeom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_31.Geometry = line23
    conGeom1_31.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_31.SplineDefiningPointIndex = 0
    conGeom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    edge7 = extrude1.FindObject("EDGE * 130 * 140 {(-59.9999999999999,60.0000000000001,-10)(-60,0.0000000000001,-10)(-60.0000000000001,-59.9999999999999,-10) EXTRUDE(2)}")
    conGeom2_31.Geometry = edge7
    conGeom2_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_31.SplineDefiningPointIndex = 0
    help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help5.Point.X = 0.0
    help5.Point.Y = 43.24344073346743
    help5.Point.Z = -10.0
    help5.Parameter = 0.0
    sketchHelpedGeometricConstraint5 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_31, conGeom2_31, help5)
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_15.Geometry = line23
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 0.0
    dimObject1_15.HelpPoint.Y = 0.0
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimObject2_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_13.Geometry = line23
    dimObject2_13.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_13.AssocValue = 0
    dimObject2_13.HelpPoint.X = 0.0
    dimObject2_13.HelpPoint.Y = 0.0
    dimObject2_13.HelpPoint.Z = 0.0
    dimObject2_13.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(0.0, 41.24344073346743, -6.7119836379150124)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_15, dimObject2_13, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint15
    dimension15 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression67 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    dimObject1_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_16.Geometry = line24
    dimObject1_16.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_16.AssocValue = 0
    dimObject1_16.HelpPoint.X = 0.0
    dimObject1_16.HelpPoint.Y = 0.0
    dimObject1_16.HelpPoint.Z = 0.0
    dimObject1_16.View = NXOpen.NXObject.Null
    dimObject2_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_14.Geometry = line24
    dimObject2_14.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_14.AssocValue = 0
    dimObject2_14.HelpPoint.X = 0.0
    dimObject2_14.HelpPoint.Y = 0.0
    dimObject2_14.HelpPoint.Z = 0.0
    dimObject2_14.View = NXOpen.NXObject.Null
    dimOrigin16 = NXOpen.Point3d(0.0, 35.955424371382442, -15.0)
    sketchDimensionalConstraint16 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_16, dimObject2_14, dimOrigin16, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint16
    dimension16 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression68 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line23
    geoms11[1] = line24
    geoms11[2] = line25
    geoms11[3] = line26
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line23
    geoms12[1] = line24
    geoms12[2] = line25
    geoms12[3] = line26
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.011329063298288174
    rotMatrix14.Xy = -0.99992226903175785
    rotMatrix14.Xz = -0.0052065554031994815
    rotMatrix14.Yx = -0.075731596111146604
    rotMatrix14.Yy = -0.0060499461754522036
    rotMatrix14.Yz = 0.99710988536957779
    rotMatrix14.Zx = -0.99706387843269328
    rotMatrix14.Zy = -0.010902020255775517
    rotMatrix14.Zz = -0.07579424964402709
    translation14 = NXOpen.Point3d(20.437053622909975, 9.8154265780618282, 0.81725868862738893)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 2.7372126561721077)
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension4 = dimension15
    sketchLinearDimensionBuilder8 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension4)
    
    sketchLinearDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId137, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits485 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits487 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits491 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder8.Driving.ExpressionValue.SetFormula("3")
    
    sketchLinearDimensionBuilder8.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    nXObject28 = sketchLinearDimensionBuilder8.Commit()
    
    point1_73 = NXOpen.Point3d(0.0, 42.24344073346743, -10.0)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line23, NXOpen.View.Null, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(0.0, 39.24344073346743, -10.0)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, NXOpen.View.Null, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    sketchLinearDimensionBuilder8.Driving.ExpressionValue.SetFormula("3")
    
    theSession.SetUndoMarkName(markId139, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId139, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point32 = workPart.Points.FindObject("ENTITY 2 6")
    assocOrigin11.PointOnGeometry = point32
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point33 = NXOpen.Point3d(0.0, 39.017581204279956, -22.112625719255945)
    sketchLinearDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point33)
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits503 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits509 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId140, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId140, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder8.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder8.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    nXObject29 = sketchLinearDimensionBuilder8.Commit()
    
    point1_75 = NXOpen.Point3d(0.0, 45.24344073346743, -10.0)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line23, NXOpen.View.Null, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(0.0, 39.24344073346743, -10.0)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, NXOpen.View.Null, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    theSession.SetUndoMarkName(markId141, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId141, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    assocOrigin12.PointOnGeometry = point32
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point34 = NXOpen.Point3d(0.0, 30.238636901240351, -25.558853577734048)
    sketchLinearDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point34)
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits515 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits521 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits523 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits525 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId142, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId142, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject30 = sketchLinearDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId144, None)
    
    theSession.SetUndoMarkName(markId137, "線性尺寸")
    
    expression69 = sketchLinearDimensionBuilder8.Driving.ExpressionValue
    sketchLinearDimensionBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId143, None)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId142, None)
    
    theSession.DeleteUndoMark(markId141, None)
    
    theSession.DeleteUndoMark(markId140, None)
    
    theSession.DeleteUndoMark(markId139, None)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.011329063298288174
    rotMatrix15.Xy = -0.99992226903175785
    rotMatrix15.Xz = -0.0052065554031994815
    rotMatrix15.Yx = 0.016588909869863597
    rotMatrix15.Yy = -0.0050182266478070708
    rotMatrix15.Yz = 0.99984980145551949
    rotMatrix15.Zx = -0.99979820983742285
    rotMatrix15.Zy = -0.011413732767786683
    rotMatrix15.Zz = 0.01653076859049913
    translation15 = NXOpen.Point3d(20.437053622909975, 9.8143006192331779, 0.77931804879545097)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 2.7372126561721077)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖約束(K)->尺寸(D)->快速(P)...
    # ----------------------------------------------
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines65 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines68)
    
    theSession.SetUndoMarkName(markId145, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    point35 = NXOpen.Point3d(5.1070259132757201e-15, 45.243440733467537, -16.452052928292527)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(line26, workPart.ModelingViews.WorkView, point35)
    
    point1_77 = NXOpen.Point3d(0.0, 45.24344073346743, -20.0)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line26, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    point1_78 = NXOpen.Point3d(0.0, 45.24344073346743, -10.0)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line26, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    edge8 = extrude1.FindObject("EDGE * 140 * 170 {(-59.9999999999999,60.0000000000001,-10)(-59.9999999999999,60.0000000000001,-5)(-59.9999999999999,60.0000000000001,0) EXTRUDE(2)}")
    point1_79 = NXOpen.Point3d(-59.999999999999929, 60.000000000000142, -5.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    point1_80 = NXOpen.Point3d(5.1070259132757201e-15, 45.243440733467537, -16.452052928292527)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    point1_81 = NXOpen.Point3d(-59.999999999999929, 60.000000000000142, -5.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    point1_82 = NXOpen.Point3d(5.1070259132757201e-15, 45.243440733467537, -16.452052928292527)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    point1_83 = NXOpen.Point3d(-59.999999999999929, 60.000000000000142, -5.0)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge8, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point36 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point36
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder12.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point37 = NXOpen.Point3d(0.0, 54.210733923455493, -25.205222581836125)
    sketchRapidDimensionBuilder12.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point37)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.TextCentered = False
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    nXObject31 = sketchRapidDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId146, None)
    
    theSession.SetUndoMarkName(markId145, "快速尺寸")
    
    theSession.SetUndoMarkVisibility(markId145, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines69 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines72)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId147, "快速尺寸 對話方塊")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    expression70 = workPart.Expressions.FindObject("p35")
    expression70.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId147, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId148, None)
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "快速尺寸")
    
    theSession.SetUndoMarkName(markId147, "Edit Driving Value")
    
    scaleAboutPoint112 = NXOpen.Point3d(-31.51167903311169, -8.4095585149714687, 0.0)
    viewCenter112 = NXOpen.Point3d(31.511679033111804, 8.4095585149716001, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-24.977355405386671, -6.1090126223700558, 0.0)
    viewCenter113 = NXOpen.Point3d(24.977355405386763, 6.1090126223701615, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-19.981884324309327, -4.8872100978960438, 0.0)
    viewCenter114 = NXOpen.Point3d(19.981884324309416, 4.8872100978961281, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    theSession.UndoToMark(markId149, None)
    
    theSession.DeleteUndoMark(markId149, None)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->圓(C)...
    # ----------------------------------------------
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression71 = workPart.Expressions.CreateSystemExpression("3")
    
    theSession.SetUndoMarkVisibility(markId151, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(0.0, 53.000000000000142, -16.599664270513884)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 1.5, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_17.Geometry = arc3
    dimObject1_17.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_17.AssocValue = 0
    dimObject1_17.HelpPoint.X = 0.0
    dimObject1_17.HelpPoint.Y = 0.0
    dimObject1_17.HelpPoint.Z = 0.0
    dimObject1_17.View = NXOpen.NXObject.Null
    dimOrigin17 = NXOpen.Point3d(0.0, 53.000000000000142, -16.038509478051381)
    sketchDimensionalConstraint17 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_17, dimOrigin17, expression71, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension17 = sketchDimensionalConstraint17.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId152, "Curve")
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    perpendicularDimension5 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    sketchLinearDimensionBuilder9 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension5)
    
    sketchLinearDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId153, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits585 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder9.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits587 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits591 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits597 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId154, None)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder9.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder9.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    nXObject32 = sketchLinearDimensionBuilder9.Commit()
    
    point1_84 = NXOpen.Point3d(0.0, 53.000000000000142, -19.999999999999996)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, NXOpen.View.Null, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    point1_85 = NXOpen.Point3d(0.0, 53.000000000000149, -16.0)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, NXOpen.View.Null, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    sketchLinearDimensionBuilder9.Driving.ExpressionValue.SetFormula("4")
    
    theSession.SetUndoMarkName(markId155, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId155, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId153, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point38 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point38
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point39 = NXOpen.Point3d(0.0, 32.93481241542645, -23.233856297414949)
    sketchLinearDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point39)
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits603 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits607 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits609 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits613 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId156, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId153, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    # ----------------------------------------------
    #   功能表：插入(S)->設計特徵(E)->拉伸(X)...
    # ----------------------------------------------
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject33 = sketchLinearDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.SetUndoMarkName(markId153, "線性尺寸")
    
    expression72 = sketchLinearDimensionBuilder9.Driving.ExpressionValue
    sketchLinearDimensionBuilder9.Destroy()
    
    theSession.DeleteUndoMark(markId157, None)
    
    theSession.SetUndoMarkVisibility(markId153, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId156, None)
    
    theSession.DeleteUndoMark(markId155, None)
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit3)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId159, "拉伸 對話方塊")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves6 = [NXOpen.ICurve.Null] * 5 
    curves6[0] = line25
    curves6[1] = line23
    curves6[2] = line26
    curves6[3] = line24
    curves6[4] = arc3
    seedPoint6 = NXOpen.Point3d(0.0, 51.500000000000142, -13.499999999999995)
    regionBoundaryRule6 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves6, seedPoint6, 0.01)
    
    section5.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = regionBoundaryRule6
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section5.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId160, None)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId162, None)
    
    direction9 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction9
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId161, None)
    
    extrudeBuilder5.Limits.SymmetricOption = True
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("-100")
    
    extrudeBuilder5.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder5.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder5.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("5")
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId163, None)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    try:
        # 工具體完全在目標體外。
        feature10 = extrudeBuilder5.CommitFeature()
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(670030)
        
    theSession.UndoToMarkWithStatus(markId164, None)
    
    theSession.DeleteUndoMark(markId164, None)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies16)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId166, None)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature11 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId167, None)
    
    theSession.SetUndoMarkName(markId159, "拉伸")
    
    expression76 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression73)
    
    workPart.Expressions.Delete(expression74)
    
    workPart.Expressions.Delete(expression75)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = -0.88191842173401591
    rotMatrix16.Xy = -0.47109551193876431
    rotMatrix16.Xz = 0.016997530330628865
    rotMatrix16.Yx = 0.047054088263348913
    rotMatrix16.Yy = -0.052096168995185224
    rotMatrix16.Yz = 0.9975329077046684
    rotMatrix16.Zx = -0.46904776961828987
    rotMatrix16.Zy = 0.88054245088308125
    rotMatrix16.Zz = 0.068111540937856374
    translation16 = NXOpen.Point3d(35.953278232809843, 13.672287928772224, 1.295125772269023)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 5.3461184690861492)
    
    scaleAboutPoint115 = NXOpen.Point3d(-15.144164961581778, -5.7904160147223998, 0.0)
    viewCenter115 = NXOpen.Point3d(15.144164961581895, 5.7904160147225348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-12.115331969265409, -4.6323328117779194, 0.0)
    viewCenter116 = NXOpen.Point3d(12.115331969265531, 4.6323328117780278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-9.6922655754123159, -3.7058662494223147, 0.0)
    viewCenter117 = NXOpen.Point3d(9.6922655754124509, 3.7058662494224444, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-7.7538124603298337, -2.964692999537835, 0.0)
    viewCenter118 = NXOpen.Point3d(7.7538124603299723, 2.9646929995379732, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-6.2030499682638478, -2.3920258047553071, 0.0)
    viewCenter119 = NXOpen.Point3d(6.203049968263989, 2.3920258047554177, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-7.753812460329832, -3.0153715123504528, 0.0)
    viewCenter120 = NXOpen.Point3d(7.7538124603299661, 3.0153715123505909, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(-9.692265575412307, -3.769214390438087, 0.0)
    viewCenter121 = NXOpen.Point3d(9.6922655754124367, 3.7692143904382167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-12.115331969265393, -4.7115179880476354, 0.0)
    viewCenter122 = NXOpen.Point3d(12.115331969265531, 4.7115179880477429, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(-9.6922655754123035, -3.7692143904380861, 0.0)
    viewCenter123 = NXOpen.Point3d(9.6922655754124349, 3.7692143904382158, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-12.115331969265394, -4.7115179880476363, 0.0)
    viewCenter124 = NXOpen.Point3d(12.115331969265533, 4.7115179880477438, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-15.144164961581767, -5.8893974850595443, 0.0)
    viewCenter125 = NXOpen.Point3d(15.144164961581895, 5.8893974850596793, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-18.930206201977224, -7.3617468563244728, 0.0)
    viewCenter126 = NXOpen.Point3d(18.930206201977352, 7.3617468563245572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(-21.961513731052012, -9.202183570405591, 0.0)
    viewCenter127 = NXOpen.Point3d(21.96151373105215, 9.2021835704056958, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(-27.451892163815028, -11.502729463006986, 0.0)
    viewCenter128 = NXOpen.Point3d(27.451892163815167, 11.502729463007118, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(-34.314865204768793, -14.378411828758733, 0.0)
    viewCenter129 = NXOpen.Point3d(34.314865204768942, 14.378411828758898, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(-42.893581505961016, -17.973014785948415, 0.0)
    viewCenter130 = NXOpen.Point3d(42.893581505961194, 17.973014785948621, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint130, viewCenter130)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = -0.99667560674183941
    rotMatrix17.Xy = -0.06420385447344229
    rotMatrix17.Xz = 0.050155757361906861
    rotMatrix17.Yx = 0.055567192215578209
    rotMatrix17.Yy = -0.085478600977351812
    rotMatrix17.Yz = 0.99478927211959423
    rotMatrix17.Zx = -0.059582061688652856
    rotMatrix17.Zy = 0.99426921598011586
    rotMatrix17.Zz = 0.088762064415052175
    translation17 = NXOpen.Point3d(-3.8891954391664285, -2.9853902332604569, 1.5016310070409804)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 1.4014528799601202)
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖(H)...
    # ----------------------------------------------
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin15, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane15
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId169, "建立草圖 對話方塊")
    
    scalar3 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude3 = feature11
    edge9 = extrude3.FindObject("EDGE * 120 * 160 {(-5,56.0000000000001,-20)(-5,56.0000000000001,-15)(-5,56.0000000000001,-10) EXTRUDE(2)}")
    point40 = workPart.Points.CreatePoint(edge9, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge10 = extrude1.FindObject("EDGE * 130 EXTRUDE(10) 160 {(5,56.0000000000001,-10)(0,56.0000000000001,-10)(-5,56.0000000000001,-10) EXTRUDE(2)}")
    direction10 = workPart.Directions.CreateDirection(edge10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude3.FindObject("FACE 160 {(0,56.0000000000001,-15) EXTRUDE(2)}")
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction10, point40, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem5
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin16, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane16.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face3
    plane16.SetGeometry(geom15)
    
    plane16.SetFlip(False)
    
    plane16.SetExpression(None)
    
    plane16.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane16.Evaluate()
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin17, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    plane17.SynchronizeToPlane(plane16)
    
    scalar4 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point41 = workPart.Points.CreatePoint(edge9, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane17.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom16 = [NXOpen.NXObject.Null] * 1 
    geom16[0] = face3
    plane17.SetGeometry(geom16)
    
    plane17.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane17.Evaluate()
    
    scaleAboutPoint131 = NXOpen.Point3d(4.8292166328899616e-14, -37.192057907897635, 0.0)
    viewCenter131 = NXOpen.Point3d(4.8292166328899616e-14, 37.192057907897635, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(5.1511644084159588e-14, -29.753646326318105, 0.0)
    viewCenter132 = NXOpen.Point3d(5.1511644084159588e-14, 29.753646326318105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(6.1813972900991496e-14, -23.802917061054401, 0.0)
    viewCenter133 = NXOpen.Point3d(6.1813972900991496e-14, 23.802917061054565, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(5.7693041374258743e-14, -19.042333648843524, 0.0)
    viewCenter134 = NXOpen.Point3d(4.9451178320793205e-14, 19.042333648843655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(5.9341413984951841e-14, -15.233866919074817, 0.0)
    viewCenter135 = NXOpen.Point3d(5.2747923542179415e-14, 15.233866919074922, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint135, viewCenter135)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId170, None)
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject34 = sketchInPlaceBuilder6.Commit()
    
    sketch6 = nXObject34
    feature12 = sketch6.Feature
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId172)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId171, None)
    
    theSession.SetUndoMarkName(markId169, "建立草圖")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression78)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point41)
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression77)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression80)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression79)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    # ----------------------------------------------
    #   功能表：插入(S)->草圖曲線(S)->矩形(R)...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId174, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint25 = NXOpen.Point3d(2.114293180481603, 56.000000000000142, -10.0)
    endPoint25 = NXOpen.Point3d(-2.2780095657288055, 56.000000000000142, -10.0)
    line27 = workPart.Curves.CreateLine(startPoint25, endPoint25)
    
    startPoint26 = NXOpen.Point3d(-2.2780095657288055, 56.000000000000142, -10.0)
    endPoint26 = NXOpen.Point3d(-2.2780095657288055, 56.000000000000142, -19.999999999999989)
    line28 = workPart.Curves.CreateLine(startPoint26, endPoint26)
    
    startPoint27 = NXOpen.Point3d(-2.2780095657288055, 56.000000000000142, -19.999999999999989)
    endPoint27 = NXOpen.Point3d(2.114293180481603, 56.000000000000142, -19.999999999999989)
    line29 = workPart.Curves.CreateLine(startPoint27, endPoint27)
    
    startPoint28 = NXOpen.Point3d(2.114293180481603, 56.000000000000142, -19.999999999999989)
    endPoint28 = NXOpen.Point3d(2.114293180481603, 56.000000000000142, -10.0)
    line30 = workPart.Curves.CreateLine(startPoint28, endPoint28)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line28, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line29, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line30, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line27
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line28
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint56 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_26.Geometry = line28
    geom1_26.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_26.SplineDefiningPointIndex = 0
    geom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_26.Geometry = line29
    geom2_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint57 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_26, geom2_26)
    
    geom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_27.Geometry = line29
    geom1_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_27.SplineDefiningPointIndex = 0
    geom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_27.Geometry = line30
    geom2_27.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint58 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_27, geom2_27)
    
    geom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_28.Geometry = line30
    geom1_28.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_28.SplineDefiningPointIndex = 0
    geom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_28.Geometry = line27
    geom2_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint59 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_28, geom2_28)
    
    geom17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom17.Geometry = line27
    geom17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint60 = theSession.ActiveSketch.CreateHorizontalConstraint(geom17)
    
    conGeom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_32.Geometry = line27
    conGeom1_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_32.SplineDefiningPointIndex = 0
    conGeom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_32.Geometry = line28
    conGeom2_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint61 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_32, conGeom2_32)
    
    conGeom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_33.Geometry = line28
    conGeom1_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_33.SplineDefiningPointIndex = 0
    conGeom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_33.Geometry = line29
    conGeom2_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint62 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_33, conGeom2_33)
    
    conGeom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_34.Geometry = line29
    conGeom1_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_34.SplineDefiningPointIndex = 0
    conGeom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_34.Geometry = line30
    conGeom2_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint63 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_34, conGeom2_34)
    
    conGeom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_35.Geometry = line30
    conGeom1_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_35.SplineDefiningPointIndex = 0
    conGeom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_35.Geometry = line27
    conGeom2_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint64 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_35, conGeom2_35)
    
    conGeom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_36.Geometry = line27
    conGeom1_36.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_36.SplineDefiningPointIndex = 0
    conGeom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    edge11 = extrude1.FindObject("EDGE * 130 * 170 {(60.0000000000001,59.9999999999999,-10)(0.0000000000001,60,-10)(-59.9999999999999,60.0000000000001,-10) EXTRUDE(2)}")
    conGeom2_36.Geometry = edge11
    conGeom2_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_36.SplineDefiningPointIndex = 0
    help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help6.Point.X = 2.114293180481603
    help6.Point.Y = 56.000000000000142
    help6.Point.Z = -10.0
    help6.Parameter = 0.0
    sketchHelpedGeometricConstraint6 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_36, conGeom2_36, help6)
    
    conGeom1_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_37.Geometry = line29
    conGeom1_37.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_37.SplineDefiningPointIndex = 0
    conGeom2_37 = NXOpen.Sketch.ConstraintGeometry()
    
    edge12 = extrude3.FindObject("EDGE * 150 * 160 {(5,56.0000000000001,-20)(0,56.0000000000001,-20)(-5,56.0000000000001,-20) EXTRUDE(2)}")
    conGeom2_37.Geometry = edge12
    conGeom2_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_37.SplineDefiningPointIndex = 0
    help7 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help7.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help7.Point.X = -2.2780095657288069
    help7.Point.Y = 56.000000000000142
    help7.Point.Z = -19.999999999999993
    help7.Parameter = 0.0
    sketchHelpedGeometricConstraint7 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_37, conGeom2_37, help7)
    
    dimObject1_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_18.Geometry = line28
    dimObject1_18.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_18.AssocValue = 0
    dimObject1_18.HelpPoint.X = 0.0
    dimObject1_18.HelpPoint.Y = 0.0
    dimObject1_18.HelpPoint.Z = 0.0
    dimObject1_18.View = NXOpen.NXObject.Null
    dimObject2_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_15.Geometry = line28
    dimObject2_15.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_15.AssocValue = 0
    dimObject2_15.HelpPoint.X = 0.0
    dimObject2_15.HelpPoint.Y = 0.0
    dimObject2_15.HelpPoint.Z = 0.0
    dimObject2_15.View = NXOpen.NXObject.Null
    dimOrigin18 = NXOpen.Point3d(-0.17367909399441572, 56.000000000000142, -14.999999999999995)
    sketchDimensionalConstraint18 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_18, dimObject2_15, dimOrigin18, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint13 = sketchDimensionalConstraint18
    dimension18 = sketchHelpedDimensionalConstraint13.AssociatedDimension
    
    expression81 = sketchHelpedDimensionalConstraint13.AssociatedExpression
    
    dimObject1_19 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_19.Geometry = line27
    dimObject1_19.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_19.AssocValue = 0
    dimObject1_19.HelpPoint.X = 0.0
    dimObject1_19.HelpPoint.Y = 0.0
    dimObject1_19.HelpPoint.Z = 0.0
    dimObject1_19.View = NXOpen.NXObject.Null
    dimObject2_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_16.Geometry = line27
    dimObject2_16.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_16.AssocValue = 0
    dimObject2_16.HelpPoint.X = 0.0
    dimObject2_16.HelpPoint.Y = 0.0
    dimObject2_16.HelpPoint.Z = 0.0
    dimObject2_16.View = NXOpen.NXObject.Null
    dimOrigin19 = NXOpen.Point3d(-0.081858192623601278, 56.000000000000142, -12.104330471734389)
    sketchDimensionalConstraint19 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_19, dimObject2_16, dimOrigin19, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint14 = sketchDimensionalConstraint19
    dimension19 = sketchHelpedDimensionalConstraint14.AssociatedDimension
    
    expression82 = sketchHelpedDimensionalConstraint14.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms13 = [NXOpen.SmartObject.Null] * 4 
    geoms13[0] = line27
    geoms13[1] = line28
    geoms13[2] = line29
    geoms13[3] = line30
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms13)
    
    geoms14 = [NXOpen.SmartObject.Null] * 4 
    geoms14[0] = line27
    geoms14[1] = line28
    geoms14[2] = line29
    geoms14[3] = line30
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms14)
    
    scaleAboutPoint136 = NXOpen.Point3d(-2.103356244664091, -5.5058442875031242, 0.0)
    viewCenter136 = NXOpen.Point3d(2.1033562446642069, 5.5058442875032929, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(-2.8611831269327892, -6.6503175382762958, 0.0)
    viewCenter137 = NXOpen.Point3d(2.8611831269329082, 6.6503175382764006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(-3.7698020929182112, -8.022912146467041, 0.0)
    viewCenter138 = NXOpen.Point3d(3.7698020929183182, 8.0229121464671724, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(-3.0158416743345557, -6.4183297171736324, 0.0)
    viewCenter139 = NXOpen.Point3d(3.0158416743346743, 6.4183297171737381, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(-2.4126733394676285, -5.1346637737388638, 0.0)
    viewCenter140 = NXOpen.Point3d(2.4126733394677555, 5.1346637737390326, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(-1.9301386715740902, -4.1077310189910907, 0.0)
    viewCenter141 = NXOpen.Point3d(1.9301386715742168, 4.1077310189912257, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint141, viewCenter141)
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    perpendicularDimension6 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    sketchLinearDimensionBuilder10 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension6)
    
    sketchLinearDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId175, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits615 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder10.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits617 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits621 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits623 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits625 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId176, None)
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.SetUndoMarkName(markId175, "線性尺寸")
    
    expression83 = sketchLinearDimensionBuilder10.Driving.ExpressionValue
    sketchLinearDimensionBuilder10.Destroy()
    
    theSession.DeleteUndoMark(markId177, None)
    
    theSession.DeleteUndoMark(markId175, None)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchLinearDimensionBuilder11 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension6)
    
    sketchLinearDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId178, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits633 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder11.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits635 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits639 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits643 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits645 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits649 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId179, None)
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point42 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point42
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point43 = NXOpen.Point3d(-13.91359072095397, 56.000000000000142, -16.56757521541634)
    sketchLinearDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point43)
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits651 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits653 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits657 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits659 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits661 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId180, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId180, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder11.Driving.ExpressionValue.SetFormula("2")
    
    sketchLinearDimensionBuilder11.Driving.ExpressionValue.SetFormula("2")
    
    sketchLinearDimensionBuilder11.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    nXObject35 = sketchLinearDimensionBuilder11.Commit()
    
    taggedObject2 = sketchLinearDimensionBuilder11.FirstAssociativity.Value
    
    line31 = taggedObject2
    point1_86 = NXOpen.Point3d(-5.0, 56.000000000000142, 4.2875000000000014)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line31, NXOpen.View.Null, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    point1_87 = NXOpen.Point3d(-3.0, 56.000000000000142, -10.0)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, NXOpen.View.Null, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    theSession.SetUndoMarkName(markId181, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId181, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject36 = sketchLinearDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId183, None)
    
    theSession.SetUndoMarkName(markId178, "線性尺寸")
    
    expression84 = sketchLinearDimensionBuilder11.Driving.ExpressionValue
    sketchLinearDimensionBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId182, None)
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId181, None)
    
    theSession.DeleteUndoMark(markId180, None)
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension5 = dimension19
    sketchLinearDimensionBuilder12 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension5)
    
    sketchLinearDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId184, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits663 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder12.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits665 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits669 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits671 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits679 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   對話開始 線性尺寸
    # ----------------------------------------------
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId185, None)
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder12.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder12.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    nXObject37 = sketchLinearDimensionBuilder12.Commit()
    
    point1_88 = NXOpen.Point3d(3.0, 56.000000000000142, -10.0)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, NXOpen.View.Null, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    point1_89 = NXOpen.Point3d(-3.0, 56.000000000000142, -10.0)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, NXOpen.View.Null, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    sketchLinearDimensionBuilder12.Driving.ExpressionValue.SetFormula("6")
    
    theSession.SetUndoMarkName(markId186, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point44 = workPart.Points.FindObject("ENTITY 2 4")
    assocOrigin16.PointOnGeometry = point44
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder12.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point45 = NXOpen.Point3d(-8.0142950888606599, 56.000000000000142, -23.060759669532477)
    sketchLinearDimensionBuilder12.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point45)
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder12.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder12.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits681 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits687 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits689 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId187, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId187, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject38 = sketchLinearDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId189, None)
    
    theSession.SetUndoMarkName(markId184, "線性尺寸")
    
    expression85 = sketchLinearDimensionBuilder12.Driving.ExpressionValue
    sketchLinearDimensionBuilder12.Destroy()
    
    theSession.DeleteUndoMark(markId188, None)
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId187, None)
    
    theSession.DeleteUndoMark(markId186, None)
    
    # ----------------------------------------------
    #   功能表：插入(S)->設計特徵(E)->拉伸(X)...
    # ----------------------------------------------
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit3)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId190, "拉伸 對話方塊")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves7 = [NXOpen.ICurve.Null] * 4 
    curves7[0] = line29
    curves7[1] = line27
    curves7[2] = line30
    curves7[3] = line28
    seedPoint7 = NXOpen.Point3d(-1.0000000000000007, 56.000000000000142, -16.666666666666664)
    regionBoundaryRule7 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves7, seedPoint7, 0.01)
    
    section6.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = regionBoundaryRule7
    helpPoint6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section6.AddToSection(rules6, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId191, None)
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId193, None)
    
    direction11 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction11
    
    expression87 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId192, None)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("-10")
    
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId194, None)
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature13 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.SetUndoMarkName(markId190, "拉伸")
    
    expression88 = extrudeBuilder6.Limits.StartExtend.Value
    expression89 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression86)
    
    workPart.Expressions.Delete(expression87)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = -0.90025139191124248
    rotMatrix18.Xy = 0.43537043258286701
    rotMatrix18.Xz = -0.00013339594418134172
    rotMatrix18.Yx = -0.010175861735053991
    rotMatrix18.Yy = -0.020735154844829892
    rotMatrix18.Yz = 0.99973321700917295
    rotMatrix18.Zx = 0.43525151717118654
    rotMatrix18.Zy = 0.90001257757109621
    rotMatrix18.Zz = 0.023097121336047147
    translation18 = NXOpen.Point3d(-4.0167776466821161, 11.695019044921052, -55.769028786639524)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 6.6826480863576947)
    
    scaleAboutPoint142 = NXOpen.Point3d(-17.499923955605592, -9.0667026828815729, 0.0)
    viewCenter142 = NXOpen.Point3d(17.49992395560572, 9.0667026828817363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(-13.999939164484463, -7.2533621463052587, 0.0)
    viewCenter143 = NXOpen.Point3d(13.999939164484587, 7.2533621463053883, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(-11.19995133158756, -5.8026897170441893, 0.0)
    viewCenter144 = NXOpen.Point3d(11.19995133158768, 5.8026897170443279, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(-8.9599610652700381, -4.6421517736353382, 0.0)
    viewCenter145 = NXOpen.Point3d(8.9599610652701571, 4.6421517736354767, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(-11.199951331587561, -5.8026897170441902, 0.0)
    viewCenter146 = NXOpen.Point3d(11.199951331587679, 5.8026897170443288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(-13.999939164484461, -7.2533621463052578, 0.0)
    viewCenter147 = NXOpen.Point3d(13.999939164484582, 7.2533621463053874, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(-17.499923955605588, -9.0667026828815995, 0.0)
    viewCenter148 = NXOpen.Point3d(17.499923955605716, 9.0667026828817079, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(-21.874904944506998, -11.333378353601997, 0.0)
    viewCenter149 = NXOpen.Point3d(21.874904944507126, 11.333378353602132, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(-27.343631180633764, -14.166722942002497, 0.0)
    viewCenter150 = NXOpen.Point3d(27.343631180633896, 14.166722942002666, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint150, viewCenter150)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.72712183506975714
    rotMatrix19.Xy = -0.68618001277189622
    rotMatrix19.Xz = -0.021232687939820753
    rotMatrix19.Yx = -0.017807667856125399
    rotMatrix19.Yy = -0.012065975249542237
    rotMatrix19.Yz = 0.99976862283570567
    rotMatrix19.Zx = -0.68627743947350839
    rotMatrix19.Zy = 0.72733170033598715
    rotMatrix19.Zz = -0.0034458316916003862
    translation19 = NXOpen.Point3d(-20.907385586825143, 3.0536721085648164, -56.03445831691598)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 3.4215158202151401)
    
    scaleAboutPoint151 = NXOpen.Point3d(3.0931709480355627, -20.801574625538709, 0.0)
    viewCenter151 = NXOpen.Point3d(-3.0931709480354308, 20.801574625538816, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(2.4745367584284717, -16.641259700430929, 0.0)
    viewCenter152 = NXOpen.Point3d(-2.4745367584283344, 16.641259700431096, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(1.9796294067427815, -13.313007760344743, 0.0)
    viewCenter153 = NXOpen.Point3d(-1.979629406742655, 13.313007760344879, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(1.5837035253942424, -10.650406208275795, 0.0)
    viewCenter154 = NXOpen.Point3d(-1.5837035253941141, 10.650406208275903, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(1.2669628203154044, -8.4886508961127145, 0.0)
    viewCenter155 = NXOpen.Point3d(-1.2669628203152747, 8.4886508961128442, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(0.93755248703341598, -6.7402422040775525, 0.0)
    viewCenter156 = NXOpen.Point3d(-0.93755248703328631, 6.740242204077691, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(1.1402665382838719, -8.4253027550969612, 0.0)
    viewCenter157 = NXOpen.Point3d(-1.1402665382837422, 8.4253027550970909, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(1.4253331728548264, -10.531628443871229, 0.0)
    viewCenter158 = NXOpen.Point3d(-1.4253331728546914, 10.531628443871337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(1.7321757308999379, -13.164535554839034, 0.0)
    viewCenter159 = NXOpen.Point3d(-1.7321757308998114, 13.164535554839169, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(2.1652196636249061, -16.455669443548789, 0.0)
    viewCenter160 = NXOpen.Point3d(-2.1652196636247796, 16.455669443548956, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(2.7065245795311133, -20.569586804436039, 0.0)
    viewCenter161 = NXOpen.Point3d(-2.7065245795309942, 20.569586804436145, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(3.3831557244138746, -25.711983505545046, 0.0)
    viewCenter162 = NXOpen.Point3d(-3.3831557244137591, 25.711983505545177, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(4.1081176653596936, -32.019152391773623, 0.0)
    viewCenter163 = NXOpen.Point3d(-4.1081176653595906, 32.019152391773787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(5.1351470816996159, -40.02394048971702, 0.0)
    viewCenter164 = NXOpen.Point3d(-5.1351470816994871, 40.023940489717226, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(6.4189338521244874, -50.029925612146279, 0.0)
    viewCenter165 = NXOpen.Point3d(-6.4189338521243906, 50.029925612146535, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(8.0236673151555884, -62.537407015183, 0.0)
    viewCenter166 = NXOpen.Point3d(-8.0236673151555085, 62.537407015183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(10.02958414394446, -78.171758768978748, 0.0)
    viewCenter167 = NXOpen.Point3d(-10.029584143944435, 78.171758768978748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint167, viewCenter167)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = -0.40695769456830488
    rotMatrix20.Xy = -0.91298901751874662
    rotMatrix20.Xz = -0.028922114753333443
    rotMatrix20.Yx = 0.35609715619253329
    rotMatrix20.Yy = -0.18772594735649051
    rotMatrix20.Yz = 0.91539815601775132
    rotMatrix20.Zx = -0.84117789449274183
    rotMatrix20.Zy = 0.36222924037032522
    rotMatrix20.Zz = 0.40150931152028901
    translation20 = NXOpen.Point3d(-11.262461058012169, -74.906335968777455, -51.984906884797084)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 0.71754387453958279)
    
    # ----------------------------------------------
    #   功能表：工具(T)->動作記錄(J)->停止錄製(S)
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()